document.querySelector('#engine').onclick=()=>chrome.tabs.create({url:chrome.runtime.getURL('engine/engine.html')});
document.querySelector('#studio').onclick=()=>chrome.tabs.create({url:'https://www.tiktok.com/tiktokstudio/upload'});
